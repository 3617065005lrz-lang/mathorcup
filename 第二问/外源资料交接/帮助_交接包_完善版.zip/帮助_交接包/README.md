# P0-4 / P0-5 / P0-6 完善版交接包

更新日期：2026-10-25。当前结论见《完善版验收摘要.md》，实际收件验收以 delivery_validation.json 为准。

本包负责资料交接及必要派生处理，不包含第二问的触发阈值模型、时空可靠性实验或第三问的区间覆盖率验证。

## 接收和验收

同时保留新版小交接包与原来的7个影像分卷。原7片不用重发、改名或重新分包。推荐摆放：

```text
交接目录/
  帮助_交接包/                  ← 新版ZIP解压后的目录
    README.md
    scripts/
    P0-4_Sentinel-1/
    P0-5_GFS/
    P0-6_Copernicus_DEM_GLO-30/
  帮助_GRD_分卷.zip.001
  ...
  帮助_GRD_分卷.zip.007
```

小包包含GFS、DEM和轻量清单；4景GRD原始ZIP在7片中，不在小包中。file_inventory.csv核验小包，external_grd_inventory.csv核验外部影像，两个清单不要混淆。

本版实际验收环境为Windows、Python 3.14；版本在 requirements.txt。进入本目录后执行：

```powershell
python -m pip install -r requirements.txt
python scripts/verify_delivery.py
```

也可双击“验收.bat”。会自动寻找本目录或上一级目录中的7片。分卷在别处时：

```powershell
python scripts/verify_delivery.py --parts-dir "D:/收到的资料"
```

验收包括文件大小和SHA-256、GFS时间与区间守恒、扩展气压层与零度层范围、DEM可读性，以及实际收到的分卷和4个原始GRD ZIP的哈希。历史完整CRC检查记录见 数据独立核查.json。

- local_package_passed=true：小包通过。
- complete_delivery_passed=true：整套资料实际核对通过。
- 返回码0：整套通过；1：有错误；2：小包通过但GRD未找到或未核对齐。返回码2不能写成全部通过。

直接校验分卷不会生成额外6.9 GB合并ZIP。如果软件需要独立GRD文件，可直接导入到正确目录：

```powershell
python scripts/grd_parts.py --parts-dir "D:/收到的资料" --import-grd
```

导入另占约6.9 GB；已有同哈希文件跳过，不同文件拒绝覆盖。也可用原合并方法，解压后将4个 *.SAFE.zip 放入 P0-4_Sentinel-1/GRD。

## 已修正和新增

### Sentinel-1

4景GRD已独立校验；修复两景已下载仍写需登录的状态，并明确保存在外部分卷。三组跨事件SLC候选对改为 post_event_validation_only=True；查询脚本同步修复逻辑。跨事件结果包含灾后信息，不能作为事前预测输入。

当前是轨道85升轨、121降轨的两组跨事件对，不是灾前/灾后连续序列。SLC仍仅有候选目录，不是已完成InSAR。还需验证burst重叠、垂直基线和相干性。

目录足迹检查显示4景包含源区AOI四角；降轨没有覆盖声明走廊的全部西侧。实际雷达阴影、叠掩和有效像元须在处理中检查。

### GFS

原文件在 P0-5_GFS/data，原数值未覆盖。新增 analysis_ready 目录中的20个 *_interval_aware.nc，保留原变量，并增加：

|变量|含义|
|---|---|
|precipitation_source_period_bounds|原降水累计区间起止时效，小时|
|shortwave_source_period_bounds|原辐射平均区间起止时效，小时|
|analysis_period_bounds|派生三小时区间，小时|
|precipitation_3h|互不重叠的前三小时降水，mm|
|shortwave_mean_3h|互不重叠的前三小时平均短波通量，W/m²，保留原差分值|
|shortwave_mean_3h_qc|显式处理微小负值的可选通量，W/m²|
|shortwave_3h_qc_flag|原值/微小负值归零/较大负值屏蔽/原始缺测|
|extended_pressure_level|400、450、500、550、600、700、850 hPa|
|air_temperature_extended|扩展气压层温度，K|
|geopotential_height_extended|扩展气压层位势高度，gpm|
|zero_degree_bracket_available|排除地下层后是否具备零度上下界|
|freezing_level_geopotential_height|最低暖到冷零度交点的位势高度估计，gpm|

原统计区间交替为3小时与6小时，不能直接逐时效相加。派生量按实际区间拆分，并重建原区间核验。+000的降水、辐射仍缺测，不当作0。

辐射拆分后有203个微小负值，最小约−0.036 W/m²，与量化/差分误差相容，机制未独立证明。原值保留；可选QC将[−0.1,0)归零，低于−0.1屏蔽并保留标志。本批没有较大负值。0.1是明示处理容差，不是已证明的不确定性界。守恒核验使用未裁剪变量。

新增400/450/550 hPa温度和位势高度在 pressure_supplement：20个起报场、820个时效、4920条GRIB消息，均通过精确字节范围获取后裁剪，没有下载完整全球GRIB。逐消息来源、字节区间和哈希在同目录凭证JSON。

排除地下层后，原四层3043/4920个剖面有上下界；补充后4920/4920都有。零度高度只对有交点的剖面线性插值，不外推。这是0.5°模式估计，不是冰川局地观测；gpm也不能直接等同DEM几何高程基准。

使用限制：

- 保留起报/有效时间，回测还需考虑实际发布延迟；不得用灾后起报预测此前事件。
- 网格中心为85.0/85.5/86.0°E、28.0/28.5°N，不能解释为高分辨率源区气象。背景AOI北缘超出纬度格点中心凸包，双线性插值若需覆盖该边缘，应补北侧格点；当前源区位于凸包内。
- grid 004是网格编号，业务模式软件版本未独立确定，不冒填版本。
- “10:30左右”没有被擅定为源区启动时间；以队友确认的事件口径为准。

### DEM与脚本

题目附件7已完整覆盖声明走廊且无nodata。外部N28E085改记为地形扩展/敏感性参考，未证明必须补边。拼接前仍需核对基准、重叠高程差和水系连续性。

脚本移除了原电脑路径，按包目录定位；NetCDF内存读写适配中文路径。清单重新生成。original_file_inventory.csv、original_validation_report.json、原始下载说明.md、完善前核查记录.md属于历史记录，不代表当前完善状态。

## 复现与维护

一般不必重下数据。重新生成派生量：

```powershell
python scripts/prepare_gfs_analysis.py
```

重新获取新增气压层：

```powershell
python scripts/download_gfs_levels.py --workers 12
python scripts/prepare_gfs_analysis.py
```

新增层只访问公开NOAA源，不需要账号。GRD仍需CDSE授权，已有影像不用重下。改动、重算或下载后，旧清单会失效；维护者核实变化后运行：

```powershell
python scripts/rebuild_inventory.py
python scripts/verify_delivery.py
```

不要对来源不明的变化盲目重建清单。

未闭环事项见 待补任务.csv：SLC与连续SAR序列、实际精轨选用、业务版本证据、发布延迟、队友最新事件口径。不能用资料下载完成代替阈值标定和时空可靠性实验。大型数据存数据目录，GitHub仅放脚本、轻量清单和说明。
