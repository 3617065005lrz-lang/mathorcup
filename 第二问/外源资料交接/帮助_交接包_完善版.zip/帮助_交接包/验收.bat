@echo off
cd /d "%~dp0"
python scripts\verify_delivery.py %*
echo Exit code: %errorlevel%
pause
